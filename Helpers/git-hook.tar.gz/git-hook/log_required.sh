#!/bin/bash

source /etc/environment
JIRAKEY="ZMP"

test "" != "$(grep '${JIRAKEY}-' "$1")" || {
        echo >&2 "ERROR: Commit message is missing Jira issue number."
        exit 1
}
