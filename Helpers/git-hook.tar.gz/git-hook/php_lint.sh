#!/bin/sh

FILE="$1"
PHP="/usr/bin/php"

$PHP -l $FILE

if [ $? -ne 0 ]
then
    exit 1
fi
