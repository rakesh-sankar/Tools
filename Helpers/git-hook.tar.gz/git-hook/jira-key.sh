#!/bin/bash

source /etc/environment

test "" != "$(grep 'ZMP-' "$1")" || {
    echo >&2 "ERROR: Commit message is missing Jira issue key."
    exit 1
}
